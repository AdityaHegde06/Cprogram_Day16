/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
//function prototype 
void swap(int x, int y);

int main()
{
    int a=10,b=20;
    //function call
    swap(a,b);
    printf("a=%d,b=%d\n",a,b);
    return 0;
}
//function defination
void swap(int x,int y)
{
    int t;
    t=x;
    x=y;
    y=t;
    printf("x=%d y=%d\n",x,y);
}