/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/* writing a progranm to overcome the limitation of for return by usingf call by reference*/ 
#include <stdio.h>
void areaperi(int ,float*,float*);

int main()
{
int radius;
float area ,perimeter;
printf("Enter radius of a circle ");
scanf("%d",&radius);
scanf(radius,&area,&perimeter);
printf("Area=%f\n",area);
printf("Perimeter=%f\n",perimeter);
return 0;
}
void areperi(int r, float *a,float *p)
{
 *a=3.14*r*r;
 *p=2*3.14*r;
}
c